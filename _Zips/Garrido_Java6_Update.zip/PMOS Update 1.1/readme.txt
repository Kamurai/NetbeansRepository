Principles of Modern Operating Systems
Software Update 1.1

This softwre update fixes the following problems:
- Under Java 1.6, some screens did not display properly
- The software could hang after completion of s simulation model

To use this update:
1) Download and unzip the software.
2) Double-click on runsim.exe
3) A screen will appear; click on USE CD FEATURES
4) A file dilaog will appear. Select the CD drive tht holds the 
    Principles of Modern Operating Systems CD
5) Select the desired feature.